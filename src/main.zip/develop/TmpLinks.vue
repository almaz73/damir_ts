<template>
  <div class="links">
    <router-link to="/">newКТ</router-link>
    <router-link to="/custom-elementplus">custom controls</router-link>
    <a target="_blank"
       href="https://www.figma.com/file/NnnFOL5H1kS4X22UM5u8dX/%D0%94%D0%B8%D1%81%D0%BF%D0%B5%D1%82%D1%87%D0%B5%D1%80%D1%81%D0%BA%D0%B0%D1%8F-%E2%80%94-%D1%81%D0%BA%D0%BE%D1%80%D0%B0%D1%8F-%D0%BF%D0%BE%D0%BC%D0%BE%D1%89%D1%8C?node-id=5-1175&t=eNkair1AloTIRB2O-0">
      Figma</a>
  </div>
</template>

<style scoped>
.links {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: #eee;
  padding: 5px;
  display: inline-flex;
  gap: 20px;
  opacity: .5;

}
</style>
