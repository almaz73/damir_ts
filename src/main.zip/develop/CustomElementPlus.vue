<template>
  <div class="custom">
    <h2>Костомизированные контролы Element Plus</h2>
    <hr/>
    <h3>Кнопки</h3>

    <el-button style="background: #efefef"> простая</el-button>
    <br>
    <el-button round style="background: #efefef"> круглая</el-button>
    <br>
    <span class="herder-menu">
    <el-button> herder-menu</el-button>
    </span>
    <br>
    <el-button class="special-little"> special-little</el-button>
    <br>
    <el-button class="special-big">special-big</el-button>
    <hr/>
  </div>
</template>
<style scoped>
.custom {
  padding: 20px 45px;
}
</style>
