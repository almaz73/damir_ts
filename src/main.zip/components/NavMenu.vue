<template>
  <div class="nav-menu">
    <span>
      <img src="@/assets/img/menu/monitoring.png"/>
      Мониторинг
    </span>
    <span class="active">
      <img src="@/assets/img/menu/newKT.png" />
      Новый КТ
    </span>
    <span>
      <img src="@/assets/img/menu/oo.png"/>
      Опер. обст.
    </span>
    <span>
      <img src="@/assets/img/menu/journal.png"/>
      Журнал
    </span>
    <span>
      <img src="@/assets/img/menu/spsJournal.png"/>
      Спец. журнал
    </span>
    <span>
      <img src="@/assets/img/menu/naryad.png"/>
      Наряды
    </span>
    <span>
      <img src="@/assets/img/menu/tabel.png"/>
      Табель
    </span>
    <span>
      <img src="@/assets/img/menu/report.png"/>
      Отчеты
    </span>
    <span>
      <img src="@/assets/img/menu/tfoms.png"/>
      ТФОМС
    </span>
    <span>
      <img src="@/assets/img/menu/pharmacy.png"/>
      Аптека
    </span>
    <span>
      <img src="@/assets/img/menu/garazh.png"/>
      Гараж
    </span>
    <span>
      <img src="@/assets/img/menu/dictin.png"/>
      Справочники
    </span>
    <span>
      <img src="@/assets/img/menu/admin.png"/>
      Админ
    </span>
  </div>
</template>


