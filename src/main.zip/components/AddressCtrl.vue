<template>
  <div style="margin-top: 10px">
    <div class="row">
      <span class="label"><a>Тип</a></span>
      <el-select style="width:100%"/>
      <span class="label"><a>Регион</a></span>
      <el-select style="width:100%"/>
    </div>
    <div class="row">
      <span class="label"><a>Объект</a></span>
      <el-select style="width:100%"/>
      <span class="label"><a>Улица</a></span>
      <el-select style="width:100%"/>
    </div>
    <div class="row">
      <span class="label"><a>Мо</a></span>
      <el-select style="width:100%"/>
      <span class="label"><a>Дом</a></span>
      <el-input/>
      <span class="label"><a>Корпус</a></span>
      <el-input/>
      <span class="label"><a>Строение</a></span>
      <el-input/>
      <span class="label"><a>Квартира</a></span>
      <el-input/>
    </div>
    <div class="row">
      <span class="label"><a>НП</a></span>
      <el-input/>
      <span class="label"><a>Подъезд</a></span>
      <el-input/>
      <span class="label"><a>Этаж</a></span>
      <el-input/>
      <span class="label"><a>Домофон</a></span>
      <el-input/>
    </div>
  </div>
</template>
